import React, { useState } from 'react';
import { SearchForm } from './components/SearchForm';
import { SearchResults } from './components/SearchResults';
import type { SearchResult } from './types';

// Mock data for demonstration
const mockResults: SearchResult[] = [
  {
    id: '1',
    rollNo: '2020CS001',
    name: 'John Doe',
    admissionYear: '2020',
    currentYear: '2nd',
    department: 'Computer Science'
  },
  {
    id: '2',
    rollNo: '2021CS002',
    name: 'Jane Smith',
    admissionYear: '2021',
    currentYear: '1st',
    department: 'Computer Science'
  }
];

function App() {
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);

  const handleSearch = (formData: FormData) => {
    // In a real application, this would make an API call
    // For now, we'll just filter the mock data
    const rollNo = formData.get('rollNo') as string;
    const admissionYear = formData.get('admissionYear') as string;
    const currentYear = formData.get('currentYear') as string;

    const filtered = mockResults.filter(result => {
      if (rollNo && !result.rollNo.toLowerCase().includes(rollNo.toLowerCase())) return false;
      if (admissionYear && result.admissionYear !== admissionYear) return false;
      if (currentYear && result.currentYear !== currentYear) return false;
      return true;
    });

    setSearchResults(filtered);
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <SearchForm onSearch={handleSearch} />
        <SearchResults results={searchResults} />
      </div>
    </div>
  );
}

export default App;
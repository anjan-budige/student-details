export const mockResults = [
  {
    id: '1',
    rollNo: '2020CS001',
    name: 'John Doe',
    admissionYear: '2020',
    currentYear: '2nd',
    department: 'Computer Science'
  },
  {
    id: '2',
    rollNo: '2021CS002',
    name: 'Jane Smith',
    admissionYear: '2021',
    currentYear: '1st',
    department: 'Computer Science'
  }
] as const;